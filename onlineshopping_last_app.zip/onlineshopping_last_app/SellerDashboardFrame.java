package onlineshopping_last_app;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;

public class SellerDashboardFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private JButton logoutButton;
    private int sellerUserId;
    private Integer managedProductId = null;
    private final String BACKGROUND_PATH = "C:\\Users\\ABCD\\Desktop\\java\\GUI\\Sphoto_2024-05-06_11-11-45.jpg";

    private JTable sellerOrderTable;
    private DefaultTableModel sellerOrderTableModel;
    private JComboBox<String> sellerOrderStatusComboBox;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private JTextField productNameField, productPriceField, productStockField;
    private JTextArea productDescArea;
    private JTextField productCategoryField, productImageUrlField;
    private JButton saveProductChangesButton;
    private JLabel managedProductNameLabel;

    public SellerDashboardFrame() {
        this.sellerUserId = OnlineShopping_last_App.currentUserId;
        fetchManagedProduct();

        setTitle("Seller Dashboard - Online Shopping CSd");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));

        JPanel statsPanel = createBackgroundPanelWithContent();
        statsPanel.setLayout(new GridBagLayout());
        managedProductNameLabel = new JLabel("", SwingConstants.CENTER);
        managedProductNameLabel.setFont(new Font("Arial", Font.ITALIC, 16));
        managedProductNameLabel.setForeground(Color.CYAN);

        JLabel welcomeLabel = new JLabel("<html><div style='text-align: center;'><h1>Welcome Seller!</h1><p>Manage your assigned product and its orders.</p></div></html>", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);

        GridBagConstraints gbcWelcome = new GridBagConstraints();
        gbcWelcome.gridx = 0; gbcWelcome.gridy = 0; gbcWelcome.insets = new Insets(10,0,5,0);
        statsPanel.add(welcomeLabel, gbcWelcome);
        GridBagConstraints gbcManagedProduct = new GridBagConstraints();
        gbcManagedProduct.gridx = 0; gbcManagedProduct.gridy = 1; gbcManagedProduct.insets = new Insets(5,0,10,0);
        statsPanel.add(managedProductNameLabel, gbcManagedProduct);
        tabbedPane.addTab("Dashboard", statsPanel);

        JPanel productManagementPanel = createSellerProductManagementPanel();
        tabbedPane.addTab("Manage My Product", productManagementPanel);

        JPanel orderManagementPanel = createSellerOrderManagementPanel();
        tabbedPane.addTab("Manage Orders (My Product)", orderManagementPanel);

        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.addActionListener(e -> {
            OnlineShopping_last_App.currentUserId = -1;
            OnlineShopping_last_App.currentUserRole = "";
            OnlineShopping_last_App.currentUsername = "";
            new LoginFrame().setVisible(true); // Changed
            this.dispose();
        });

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topPanel.setBackground(new Color(50, 50, 50));
        JLabel loggedInAsLabel = new JLabel("Logged in as: " + OnlineShopping_last_App.currentUsername + " (Seller)  ");
        loggedInAsLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        loggedInAsLabel.setForeground(Color.WHITE);
        topPanel.add(loggedInAsLabel);
        topPanel.add(logoutButton);

        add(topPanel, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);

        if (managedProductId == null) {
            JOptionPane.showMessageDialog(this,
                "You are not currently assigned to manage a specific product. Product management and order viewing features will be disabled. Please contact an administrator.",
                "Product Assignment Warning", JOptionPane.WARNING_MESSAGE);
            managedProductNameLabel.setText("No Product Assigned. Contact Admin.");
        } else {
            loadManagedProductDetails();
            loadSellerOrders();
        }
    }

    private void fetchManagedProduct() {
        String sql = "SELECT managed_product_id FROM users WHERE user_id = ? AND role = 'seller'";
        try (Connection conn = OnlineShopping_last_App.getConnection(); // Changed
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sellerUserId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int tempProductId = rs.getInt("managed_product_id");
                if (!rs.wasNull()) {
                    this.managedProductId = tempProductId;
                } else {
                    this.managedProductId = null;
                    System.out.println("Seller " + OnlineShopping_last_App.currentUsername + " has no managed_product_id assigned (DB value is NULL).");
                }
            } else {
                 System.out.println("Seller " + OnlineShopping_last_App.currentUsername + " not found or not a seller role.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching managed product: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            this.managedProductId = null;
        }
    }

    private BackgroundPanel createBackgroundPanelWithContent() {
        BackgroundPanel panel = new BackgroundPanel(BACKGROUND_PATH);
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        return panel;
    }

    private void loadManagedProductDetails() {
        if (managedProductId == null) {
             if(managedProductNameLabel!=null) managedProductNameLabel.setText("No Product Assigned.");
             if(productNameField!=null) productNameField.setText("");
             // ... clear other fields
            return;
        }
        String sql = "SELECT name, description, price, stock_quantity, category, image_url FROM products WHERE product_id = ?";
        try (Connection conn = OnlineShopping_last_App.getConnection(); // Changed
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, managedProductId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String productName = rs.getString("name");
                if(managedProductNameLabel!=null) managedProductNameLabel.setText("Managing Product: " + productName + " (ID: " + managedProductId + ")");
                if(productNameField!=null) productNameField.setText(productName);
                if(productDescArea!=null) productDescArea.setText(rs.getString("description"));
                if(productPriceField!=null) productPriceField.setText(String.format("%.2f", rs.getDouble("price")));
                if(productStockField!=null) productStockField.setText(String.valueOf(rs.getInt("stock_quantity")));
                if(productCategoryField!=null) productCategoryField.setText(rs.getString("category"));
                if(productImageUrlField!=null) productImageUrlField.setText(rs.getString("image_url") == null ? "" : rs.getString("image_url"));
            } else {
                JOptionPane.showMessageDialog(this, "Assigned product (ID: " + managedProductId + ") not found in database.", "Product Error", JOptionPane.ERROR_MESSAGE);
                if(managedProductNameLabel!=null) managedProductNameLabel.setText("Error: Assigned product not found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading managed product details: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
             if(managedProductNameLabel!=null) managedProductNameLabel.setText("Error loading product details.");
        }
    }

    private JPanel createSellerProductManagementPanel() {
        BackgroundPanel panel = createBackgroundPanelWithContent();
        JLabel titleLabel = new JLabel("Manage Your Assigned Product", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22)); titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.NORTH);

        if (managedProductId == null) {
            JLabel noProductLabel = new JLabel("No product assigned. Product management is disabled.", SwingConstants.CENTER);
            noProductLabel.setFont(new Font("Arial", Font.ITALIC, 18)); noProductLabel.setForeground(Color.ORANGE);
            panel.add(noProductLabel, BorderLayout.CENTER);
            return panel;
        }

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200,200,200,150), 1),
            BorderFactory.createEmptyBorder(20,20,20,20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8); gbc.fill = GridBagConstraints.HORIZONTAL; gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("Arial", Font.BOLD, 14); Font fieldFont = new Font("Arial", Font.PLAIN, 14);

        productNameField = new JTextField(30); productNameField.setFont(fieldFont);
        productDescArea = new JTextArea(4, 30); productDescArea.setFont(fieldFont); productDescArea.setLineWrap(true); productDescArea.setWrapStyleWord(true);
        productPriceField = new JTextField(10); productPriceField.setFont(fieldFont);
        productStockField = new JTextField(10); productStockField.setFont(fieldFont);
        productCategoryField = new JTextField(20); productCategoryField.setFont(fieldFont);
        productImageUrlField = new JTextField(30); productImageUrlField.setFont(fieldFont);

        int y = 0;
        formPanel.add(createStyledFormLabel("Product Name:"), gbc(0, y, gbc, labelFont));
        formPanel.add(productNameField, gbc(1, y++, gbc, labelFont));
        formPanel.add(createStyledFormLabel("Description:"), gbc(0, y, gbc, labelFont));
        gbc.ipady = 40; formPanel.add(new JScrollPane(productDescArea), gbc(1, y++, gbc, labelFont)); gbc.ipady = 0;
        formPanel.add(createStyledFormLabel("Price (USD):"), gbc(0, y, gbc, labelFont));
        formPanel.add(productPriceField, gbc(1, y++, gbc, labelFont));
        formPanel.add(createStyledFormLabel("Stock Quantity:"), gbc(0, y, gbc, labelFont));
        formPanel.add(productStockField, gbc(1, y++, gbc, labelFont));
        formPanel.add(createStyledFormLabel("Category:"), gbc(0, y, gbc, labelFont));
        formPanel.add(productCategoryField, gbc(1, y++, gbc, labelFont));
        formPanel.add(createStyledFormLabel("Image URL (Optional):"), gbc(0, y, gbc, labelFont));
        formPanel.add(productImageUrlField, gbc(1, y++, gbc, labelFont));

        saveProductChangesButton = new JButton("Save Product Changes");
        saveProductChangesButton.setFont(new Font("Arial", Font.BOLD, 16));
        saveProductChangesButton.setBackground(new Color(60, 179, 113)); saveProductChangesButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER; gbc.insets = new Insets(20,0,0,0);
        formPanel.add(saveProductChangesButton, gbc);
        panel.add(formPanel, BorderLayout.CENTER);

        saveProductChangesButton.addActionListener(e -> saveSellerProductChanges());
        loadManagedProductDetails();
        return panel;
    }

    private JLabel createStyledFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14)); label.setForeground(Color.WHITE);
        return label;
    }

    private GridBagConstraints gbc(int x, int y, GridBagConstraints c, Font labelFont) {
        c.gridx = x; c.gridy = y; return c;
    }

    private void saveSellerProductChanges() {
        if (managedProductId == null) return;
        try {
            String name = productNameField.getText().trim(); String desc = productDescArea.getText().trim();
            double price = Double.parseDouble(productPriceField.getText().trim());
            int stock = Integer.parseInt(productStockField.getText().trim());
            String category = productCategoryField.getText().trim(); String imageUrl = productImageUrlField.getText().trim();

            if (name.isEmpty() || desc.isEmpty() || category.isEmpty() || price <= 0 || stock < 0) {
                JOptionPane.showMessageDialog(this, "Name, Description, Category, valid Price (>0), and Stock (>=0) are required.", "Validation Error", JOptionPane.ERROR_MESSAGE); return;
            }
            String sql = "UPDATE products SET name=?, description=?, price=?, stock_quantity=?, category=?, image_url=? WHERE product_id=?";
            try (Connection conn = OnlineShopping_last_App.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) { // Changed
                pstmt.setString(1, name); pstmt.setString(2, desc); pstmt.setDouble(3, price);
                pstmt.setInt(4, stock); pstmt.setString(5, category);
                pstmt.setString(6, imageUrl.isEmpty() ? null : imageUrl); pstmt.setInt(7, managedProductId);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Product details updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadManagedProductDetails();
                    if(managedProductNameLabel!=null) managedProductNameLabel.setText("Managing Product: " + name + " (ID: " + managedProductId + ")");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update product details. Product might not exist or no changes were made.", "Update Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "DB Error updating product: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid number format for Price or Stock.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createSellerOrderManagementPanel() {
        BackgroundPanel panel = createBackgroundPanelWithContent();
        String titleText = (managedProductId != null) ?
                           "Manage Orders for Your Product (ID: " + managedProductId + ")" :
                           "Order Management (No Product Assigned)";
        JLabel titleLabel = new JLabel(titleText, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22)); titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.NORTH);

        sellerOrderTableModel = new DefaultTableModel(
            new String[]{"Order ID", "Customer", "Order Date", "Product Name", "Qty", "Unit Price", "Item Total", "Order Status"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        sellerOrderTable = new JTable(sellerOrderTableModel);
        sellerOrderTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sellerOrderTable.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(sellerOrderTable);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel controlsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        controlsPanel.setOpaque(false);
        JButton refreshButton = new JButton("Refresh My Orders"); refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        JLabel statusLabel = new JLabel("Set Order Status:"); statusLabel.setForeground(Color.WHITE); statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        sellerOrderStatusComboBox = new JComboBox<>(new String[]{"pending", "processing", "ready_for_pickup", "shipped_by_seller"});
        sellerOrderStatusComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        JButton updateStatusButton = new JButton("Update Status"); updateStatusButton.setFont(new Font("Arial", Font.BOLD, 14));
        controlsPanel.add(refreshButton); controlsPanel.add(statusLabel);
        controlsPanel.add(sellerOrderStatusComboBox); controlsPanel.add(updateStatusButton);
        panel.add(controlsPanel, BorderLayout.SOUTH);

        if (managedProductId == null) {
            refreshButton.setEnabled(false); updateStatusButton.setEnabled(false);
            sellerOrderStatusComboBox.setEnabled(false); sellerOrderTable.setEnabled(false);
            JLabel noProductLabel = new JLabel("No product assigned. Order management is disabled.", SwingConstants.CENTER);
            noProductLabel.setFont(new Font("Arial", Font.ITALIC, 16)); noProductLabel.setForeground(Color.ORANGE);
            panel.remove(scrollPane); panel.add(noProductLabel, BorderLayout.CENTER);
        } else {
            refreshButton.addActionListener(e -> loadSellerOrders());
            updateStatusButton.addActionListener(e -> updateSellerOrderStatus());
        }
        return panel;
    }

    private void loadSellerOrders() {
        if (managedProductId == null) { sellerOrderTableModel.setRowCount(0); return; }
        sellerOrderTableModel.setRowCount(0);
        String sql = "SELECT o.order_id, u.username AS customer_username, o.order_date, " +
                     "p.name AS product_name, oi.quantity, oi.price_at_purchase, o.status " +
                     "FROM orders o " +
                     "JOIN users u ON o.user_id = u.user_id " +
                     "JOIN order_items oi ON o.order_id = oi.order_id " +
                     "JOIN products p ON oi.product_id = p.product_id " +
                     "WHERE oi.product_id = ? ORDER BY o.order_date DESC";
        try (Connection conn = OnlineShopping_last_App.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) { // Changed
            pstmt.setInt(1, managedProductId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                double unitPrice = rs.getDouble("price_at_purchase"); int quantity = rs.getInt("quantity");
                sellerOrderTableModel.addRow(new Object[]{
                    rs.getInt("order_id"), rs.getString("customer_username"), sdf.format(rs.getTimestamp("order_date")),
                    rs.getString("product_name"), quantity, String.format("%.2f", unitPrice),
                    String.format("%.2f", unitPrice * quantity), rs.getString("status")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading your orders: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateSellerOrderStatus() {
        if (managedProductId == null) return;
        int selectedRowView = sellerOrderTable.getSelectedRow();
        if (selectedRowView == -1) {
            JOptionPane.showMessageDialog(this, "Please select an order to update.", "No Order Selected", JOptionPane.WARNING_MESSAGE); return;
        }
        int selectedRowModel = sellerOrderTable.convertRowIndexToModel(selectedRowView);
        int orderId = (int) sellerOrderTableModel.getValueAt(selectedRowModel, 0);
        String newStatus = (String) sellerOrderStatusComboBox.getSelectedItem();
        String sql = "UPDATE orders SET status = ? WHERE order_id = ? " +
                     "AND EXISTS (SELECT 1 FROM order_items WHERE order_id = orders.order_id AND product_id = ?)";
        try (Connection conn = OnlineShopping_last_App.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) { // Changed
            pstmt.setString(1, newStatus); pstmt.setInt(2, orderId); pstmt.setInt(3, managedProductId);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Order status updated successfully for order ID: " + orderId, "Success", JOptionPane.INFORMATION_MESSAGE);
                loadSellerOrders();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update order status. The order might not contain your product, or status was already set.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error updating order status: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}