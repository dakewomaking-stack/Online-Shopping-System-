package onlineshopping_last_app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RegistrationForm extends JFrame {
    private JTextField usernameField, fullNameField, emailField, phoneField;
    private JPasswordField passwordField, confirmPasswordField;
    private JTextArea addressArea;
    private JButton registerButton, backToLoginButton;

    public RegistrationForm() {
        setTitle("Customer Registration");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        String bgPath = "C:\\Users\\ABCD\\Desktop\\java\\GUI\\Rphoto_2019-12-06_17-26-25.jpg"; // UPDATE PATH IF NEEDED
        BackgroundPanel backgroundPanel = new BackgroundPanel(bgPath);
        backgroundPanel.setLayout(new GridBagLayout());
        setContentPane(backgroundPanel);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        formPanel.setBackground(new Color(0,0,0,120));


        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("New Customer Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;

        formPanel.add(createLabel("Username:"), gbc(0, 1, gbc));
        usernameField = new JTextField(25);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(usernameField, gbc(1, 1, gbc));

        formPanel.add(createLabel("Password:"), gbc(0, 2, gbc));
        passwordField = new JPasswordField(25);
        formPanel.add(passwordField, gbc(1, 2, gbc));

        formPanel.add(createLabel("Confirm Password:"), gbc(0, 3, gbc));
        confirmPasswordField = new JPasswordField(25);
        formPanel.add(confirmPasswordField, gbc(1, 3, gbc));

        formPanel.add(createLabel("Full Name:"), gbc(0, 4, gbc));
        fullNameField = new JTextField(25);
        fullNameField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(fullNameField, gbc(1, 4, gbc));

        formPanel.add(createLabel("Email:"), gbc(0, 5, gbc));
        emailField = new JTextField(25);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(emailField, gbc(1, 5, gbc));

        formPanel.add(createLabel("Phone Number:"), gbc(0, 6, gbc));
        phoneField = new JTextField(25);
        phoneField.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(phoneField, gbc(1, 6, gbc));

        formPanel.add(createLabel("Address:"), gbc(0, 7, gbc));
        addressArea = new JTextArea(3, 25);
        addressArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(addressArea);
        gbc.fill = GridBagConstraints.BOTH;
        formPanel.add(scrollPane, gbc(1, 7, gbc));
        gbc.fill = GridBagConstraints.HORIZONTAL;

        registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(registerButton, gbc);

        backToLoginButton = new JButton("Back to Login");
        backToLoginButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridy = 9;
        formPanel.add(backToLoginButton, gbc);

        backgroundPanel.add(formPanel, new GridBagConstraints());

        registerButton.addActionListener(e -> handleRegistration());
        backToLoginButton.addActionListener(e -> {
            new LoginFrame().setVisible(true); // Changed
            this.dispose();
        });
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        return label;
    }

    private GridBagConstraints gbc(int x, int y, GridBagConstraints gbc) {
        gbc.gridx = x;
        gbc.gridy = y;
        return gbc;
    }

    private void handleRegistration() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressArea.getText().trim();

        if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username, Password, Full Name, and Email are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            JOptionPane.showMessageDialog(this, "Invalid email format.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (phone.length() > 0 && !phone.matches("^\\+?[0-9. ()-]{7,25}$")) {
             JOptionPane.showMessageDialog(this, "Invalid phone number format.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String checkUserSql = "SELECT user_id FROM users WHERE username = ? OR email = ?";
        try (Connection conn = OnlineShopping_last_App.getConnection(); // Changed
             PreparedStatement checkStmt = conn.prepareStatement(checkUserSql)) {
            checkStmt.setString(1, username);
            checkStmt.setString(2, email);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Username or Email already exists.", "Registration Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error checking user: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
            return;
        }

        String sql = "INSERT INTO users (username, password, role, full_name, email, phone_number, address) VALUES (?, ?, 'customer', ?, ?, ?, ?)";
        try (Connection conn = OnlineShopping_last_App.getConnection(); // Changed
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, fullName);
            pstmt.setString(4, email);
            pstmt.setString(5, phone.isEmpty() ? null : phone);
            pstmt.setString(6, address.isEmpty() ? null : address);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Registration successful! Please login.", "Success", JOptionPane.INFORMATION_MESSAGE);
                new LoginFrame().setVisible(true); // Changed
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Registration failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error during registration: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}